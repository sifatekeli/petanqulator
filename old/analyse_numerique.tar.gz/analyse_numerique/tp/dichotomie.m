% dichotomie.m
function [x n] = dichotomie(min, max, fonction, epsilon)
if max - min < epsilon
    x = min;
    n = 0;
else
    milieu = (max+min)/2;
    if fonction(min)*fonction(milieu) < 0
        [x n] = dichotomie(min, milieu, fonction, epsilon);
        n = n+1;
    else
        [x n] = dichotomie(milieu, max, fonction, epsilon);
        n = n+1;
    end
end
