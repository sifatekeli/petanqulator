% test_jacobi.m
A = [-3 2 1; 2 5 1; 2 3 4];
b = [-9; 2; 2];
x0 = [0;0;0];
[x n] = jacobi(A, x0, b, 0.01)
inv(A)*b
