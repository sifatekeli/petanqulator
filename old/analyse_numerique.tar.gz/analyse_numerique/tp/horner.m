% horner.m
r1 = 1; r2 = 1; x = 3;
n = 10;     % Pour v�rifier que r1 = r2.
%n=1e6;     % Pour v�rifier que Horner est plus rapide.
t1 = cputime;
for i=n:-1:1
    r1 = r1 + x^i;
end
t2 = cputime;
for i=n:-1:1
    r2 = r2*x + 1;
end
t3 = cputime;
r1, r2, t2-t1, t3-t2
