% test_newton_raphson.m
[x n] = newton_raphson(pi/3, @cos, @(x)-sin(x), 0.01)
