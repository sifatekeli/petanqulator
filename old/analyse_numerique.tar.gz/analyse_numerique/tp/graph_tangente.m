% graph_tangente.m
clear all; close all;
x = pi/3; n = 9;
N = [n:-2:1];
l = length(N);
for i=1:l
    T(i) = tangente(x, N(i));
end
plot(N, tan(x)-T);
tan(x), T(l)
