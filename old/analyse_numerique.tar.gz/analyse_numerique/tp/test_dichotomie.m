% test_dichotomie.m
[x n] = dichotomie(pi/4, 2*pi/3, @cos, 0.01)
