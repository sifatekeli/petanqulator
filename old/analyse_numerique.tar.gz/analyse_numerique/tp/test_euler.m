% test_euler.m
% bilan des forces
force_gravite = [0; -9.8]; force_vent = [-30; 0]; masse = 70;
f = @(R)[(force_gravite+force_vent)/masse; R(1:2)];
% conditions initiales
vitesse_initiale = [5; 1]; position_initiale = [0; 0];
T1 = 0; R1 = [vitesse_initiale; position_initiale];
% resolution
h = 0.5; n = 50;
[T R] = euler(T1, R1, h, n, f);
plot(R(3,:), R(4,:));
title('Trajectoire du skieur');
