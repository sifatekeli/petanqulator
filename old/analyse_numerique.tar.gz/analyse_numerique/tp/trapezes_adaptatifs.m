% trapezes_adaptatifs.m
function [I n] = trapezes_adaptatifs(f, a, b, e)
n=1
I0 = trapezes(f, a, b, n);
while 1
   n = 2*n;
   I = trapezes(f, a, b, n);
    if (abs(I - I0) < e)
        break;
    end
    I0 = I;
end
