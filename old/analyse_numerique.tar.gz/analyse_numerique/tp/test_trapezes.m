% test_trapezes.m
f=@(x)x.*cos(x);
[I n] = trapezes_adaptatifs(f, 0, pi/2, 0.01)
% verification
syms x;
eval(int(x.*cos(x), 0, pi/2))
