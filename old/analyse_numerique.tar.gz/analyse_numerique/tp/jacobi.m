% jacobi.m
function [x n] = jacobi(A, xInitial, b, epsilon)
n = 0;
x = xInitial;
D = diag(A); E = -tril(A, -1); F = -triu(A, 1);
D1 = 1./D; LU = E+F;
while n<100
    n = n+1;
    x0 = x;
    x = D1 .*(LU*x + b);
    r = b - A*x;
    if norm(r)/norm(b) < epsilon
        break;
    end
end
