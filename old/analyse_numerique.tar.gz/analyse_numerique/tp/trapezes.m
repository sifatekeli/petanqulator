% trapezes.m
function I = trapezes(f, a, b, n)
h = (b-a)/n;
x = [a:h:b];
[l c] = size(x);
y = ones([l c]);
y(1) = 0.5;
y(end) = 0.5;
I = h*sum(f(x).*y);
