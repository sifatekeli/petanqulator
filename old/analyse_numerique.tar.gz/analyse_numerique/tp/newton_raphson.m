% newton_raphson.m
function [x n] = newton_raphson(xInitial, fonction, derivee, epsilon)
x0 = xInitial - 2*epsilon;
x = xInitial;
n = 0;
while abs(x0 - x) > epsilon
    n = n+1;
    x0 = x;
    x = x0 - fonction(x0)/derivee(x0);
end
    