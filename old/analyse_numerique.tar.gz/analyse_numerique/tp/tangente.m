% tangente.m
function r = tangente(x,n)
x2 = x*x; r = 1;
for i=n:-2:1
    r = i - x2/r;
end
r = x/r;
