% euler.m
function [T R] = euler(T1, R1, h, n, f)
T = zeros(1, n);
R = zeros(size(R1, 1), n);
R(:,1) = R1;
for i=1:n-1
    T(:, i+1) = T(:, i) + h;
    R(:, i+1) = R(:, i) + h*f(R(:, i));
end
