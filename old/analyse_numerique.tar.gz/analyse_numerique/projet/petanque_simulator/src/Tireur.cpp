#include "Tireur.hpp"

float & Tireur::Theta()
{
  return _theta;
}

float & Tireur::Phi()
{
  return _phi;
}

Vecteur3 & Tireur::Position()
{
  return _position;
}

float & Tireur::Vitesse()
{
  return _vitesse;
}
