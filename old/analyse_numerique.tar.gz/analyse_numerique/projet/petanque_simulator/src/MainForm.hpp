#ifndef INCLUDE_MAINFORM
#define INCLUDE_MAINFORM

#include "ui_MainForm.h"

// formulaire issu de QtDesigner a integrer dans la fenetre du programme
class MainForm : public QWidget, public Ui_MainWindow
{
 public:
  MainForm(QWidget *parent, QMainWindow *window);
};

#endif
