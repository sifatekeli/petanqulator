#include <QObject>
#include <QtTest/QtTest>

#include "Vecteur3.hpp"
#include "utils.hpp"

class TestVecteur3 : public QObject
{
  Q_OBJECT

  private slots:

  void testConstructeur()
  {
    Vecteur3 v(1, 2, 3);
    QVERIFY(EGAL(v.X(), 1));
    QVERIFY(EGAL(v.Y(), 2));
    QVERIFY(EGAL(v.Z(), 3));
  }

  void testAffectation()
  {
    Vecteur3 v1(2, -3, 0);
    Vecteur3 v2;
    v2 = v1;
    QVERIFY(EGAL(v2.X(), 2));
    QVERIFY(EGAL(v2.Y(), -3));
    QVERIFY(EGAL(v2.Z(), 0));
  }

  void testVecteur3FoisFloat()
  {
    Vecteur3 v1(2, 1.5, -1);
    Vecteur3 v2 = v1 * 2.3f;
    QVERIFY(EGAL(v2.X(), 4.6));
    QVERIFY(EGAL(v2.Y(), 3.45));
    QVERIFY(EGAL(v2.Z(), -2.3));
  }

  void testVecteur3PlusEgalVecteur3()
  {
    Vecteur3 v1(0, -2, 78);
    Vecteur3 v2(3, 0, -3);
    v2 += v1;
    QVERIFY(EGAL(v2.X(), 3));
    QVERIFY(EGAL(v2.Y(), -2));
    QVERIFY(EGAL(v2.Z(), 75));
  }

  void testVecteur3DiviserParFloat()
  {
    Vecteur3 v1(1.67912f, 0.61065f, 1.40633f);
    float k = 18.122f;
    Vecteur3 v2 = v1 / k;
    QVERIFY(PROCHE(v2.X(), 0.092659, 1e-5));
    QVERIFY(PROCHE(v2.Y(), 0.033697, 1e-5));
    QVERIFY(PROCHE(v2.Z(), 0.077605, 1e-5));
  }

  void testMoinsVecteur3()
  {
    Vecteur3 v1(-8.4467f,  1.8492f, -9.5468f);
    Vecteur3 v2 = -v1;
    QVERIFY(EGAL(v2.X(), 8.4467));
    QVERIFY(EGAL(v2.Y(), -1.8492));
    QVERIFY(EGAL(v2.Z(), 9.5468));
  }

  void testNorme2Carree()
  {
    Vecteur3 v(2.66542f, 1.00224f, 0.88948f);
    float norme = v.Norme2Carree();
    QVERIFY(PROCHE(norme, 8.9001f, 1e-4));
  }

  void testConstructeur2()
  {
    Vecteur3 v1(1, 2, 3);
    Vecteur3 v2(-1, 0, 54);
    Vecteur3 v3(v1, v2);

    QVERIFY(EGAL(v3.X(), -2));
    QVERIFY(EGAL(v3.Y(), -2));
    QVERIFY(EGAL(v3.Z(), 51));
  }

  void testVecteur3PlusVecteur3()
  {
    Vecteur3 v1(1, 2, 3);
    Vecteur3 v2(-1, 0, 54);
    Vecteur3 v3 = v1 + v2;

    QVERIFY(EGAL(v3.X(), 0));
    QVERIFY(EGAL(v3.Y(), 2));
    QVERIFY(EGAL(v3.Z(), 57));
  }

  void testVecteur3MoinsVecteur3()
  {
    Vecteur3 v1(1, 2, 3);
    Vecteur3 v2(-1, 0, 54);
    Vecteur3 v3 = v1 - v2;

    QVERIFY(EGAL(v3.X(), 2));
    QVERIFY(EGAL(v3.Y(), 2));
    QVERIFY(EGAL(v3.Z(), -51));
  }

  void testNorme2()
  {
    Vecteur3 v(0, 4, 3);
    float k = v.Norme2();
    QVERIFY(EGAL(k, 5));
  }

  void testNormaliser1()
  {
    Vecteur3 v(-6.0925f, 4.6329f, -12.2297f);
    v.Normaliser();
    float k = v.Norme2();
    QVERIFY(PROCHE(k, 1, 1e-5));
    QVERIFY(PROCHE(v.X(), -0.4222, 1e-4));
    QVERIFY(PROCHE(v.Y(), 0.32112, 1e-4));
    QVERIFY(PROCHE(v.Z(), -0.84768, 1e-4));
  }

  void testNormaliser2()
  {
    Vecteur3 v(0, 0, 0);
    v.Normaliser();
    float k = v.Norme2();
    QVERIFY(PROCHE(k, 0, 1e-5));
  }

  void testVecteur3DiviserEgalFloat()
  {
    Vecteur3 v(-6.0213f, -6.0636f, -12.7132f);
    float k = -9.9918f;
    v /= k;
    QVERIFY(PROCHE(v.X(), 0.6026, 1e-4));
    QVERIFY(PROCHE(v.Y(), 0.6068, 1e-4));
    QVERIFY(PROCHE(v.Z(), 1.2723, 1e-4));
  }

  void testProduitScalaire()
  {
    Vecteur3 v1(4.6027f, 1.7152f, -8.6887f);
    Vecteur3 v2(13.842f,  -11.172f, -13.896f);
    float k = ProduitScalaire(v1, v2);
    QVERIFY(PROCHE(k, 165.29f, 1e-2));
  }
};

