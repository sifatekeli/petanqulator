#include "TestEnsemble.hpp"
#include "TestVecteur3.hpp"

int main()
{
  QTest::qExec(new TestEnsemble());
  QTest::qExec(new TestVecteur3());
}
