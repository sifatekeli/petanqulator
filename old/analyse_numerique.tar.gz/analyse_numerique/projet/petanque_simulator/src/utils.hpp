#ifndef INCLUDE_UTILS
#define INCLUDE_UTILS

#include <QMessageBox>
#include <QString>

#define _USE_MATH_DEFINES
#include <cmath>

#define EPSILON 1e-6
#define INFINI 1e6
#define EGAL(a,b) (fabs( (a) - (b)) < EPSILON)
#define PROCHE(a,b, e) (fabs( (a) - (b)) < (e))

static void Message(QString s)
{
  QMessageBox msgBox;
  msgBox.setText(s);
  msgBox.exec();
}

static void Message(float f)
{
  QMessageBox msgBox;
  QString s;
  s.sprintf("%f", f);
  msgBox.setText(s);
  msgBox.exec();
}

static void Message(int i)
{
  QMessageBox msgBox;
  QString s;
  s.sprintf("%d", i);
  msgBox.setText(s);
  msgBox.exec();
}

#endif
