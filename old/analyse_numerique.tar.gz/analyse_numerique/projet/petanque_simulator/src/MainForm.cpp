#include "MainForm.hpp"

MainForm::MainForm(QWidget *parent, QMainWindow *window) : QWidget(parent)
{
  setupUi(window);
}

