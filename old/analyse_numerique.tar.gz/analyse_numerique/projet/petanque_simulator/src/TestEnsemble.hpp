#include <QObject>
#include <QtTest/QtTest>

#include "Ensemble.hpp"
#include "utils.hpp"

class TestEnsemble : public QObject
{
  Q_OBJECT

  private slots:

  void testConstructeur()
  {
    Ensemble<int> e;
  }

  void testAjout()
  {
    Ensemble<int> e;
    e.Ajouter(new int);
  }

  void testTaille()
  {
    Ensemble<int> e;
    int t;

    t = e.Taille();
    QVERIFY(t == 0);

    e.Ajouter(new int);
    t = e.Taille();
    QVERIFY(t == 1);

    e.Ajouter(new int);
    t = e.Taille();
    QVERIFY(t == 2);
  }

  void testIndexage()
  {
    Ensemble<int> e;
    int * n;
    int * i;

    i = new int;
    *i = 12;
    e.Ajouter(i);
    n = e[0];
    QVERIFY(*n == 12);

    i = new int;
    e.Ajouter(i);
    *i = 2;
    n = e[0];
    QVERIFY(*n == 12);
    n = e[1];
    QVERIFY(*n == 2);
  }
};
