#include "Calculateur.hpp"

void Calculateur::AjouterSphere(ObjetSphere * sphere)
{
  _spheres.Ajouter(sphere);
}

void Calculateur::AjouterForce(Force * force)
{
  _forces.Ajouter(force);
}

ObjetPlan & Calculateur::Plan()
{
  return _plan;
}

void Calculateur::Maj(float duree)
{
}

void Calculateur::CalculerCollisions()
{
}

void Calculateur::CalculerCollision(ObjetSphere & sphere1, ObjetSphere & sphere2) const
{
}

void Calculateur::CalculerCollision(ObjetSphere & sphere, ObjetPlan & plan) const
{
}


