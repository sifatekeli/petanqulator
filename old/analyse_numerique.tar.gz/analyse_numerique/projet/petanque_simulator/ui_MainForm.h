/********************************************************************************
** Form generated from reading UI file 'MainForm.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINFORM_H
#define UI_MAINFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDoubleSpinBox>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QLabel *label_3;
    QDoubleSpinBox *doubleSpinBox_vitesse;
    QPushButton *pushButton_tirer;
    QGroupBox *groupBox_2;
    QLabel *label_4;
    QDoubleSpinBox *doubleSpinBox_theta;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox_phi;
    QPushButton *pushButton_simuler;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(700, 400);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(400, 300));
        MainWindow->setToolButtonStyle(Qt::ToolButtonIconOnly);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 171, 191));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 120, 61, 16));
        doubleSpinBox_vitesse = new QDoubleSpinBox(groupBox);
        doubleSpinBox_vitesse->setObjectName(QString::fromUtf8("doubleSpinBox_vitesse"));
        doubleSpinBox_vitesse->setGeometry(QRect(80, 110, 81, 25));
        doubleSpinBox_vitesse->setDecimals(2);
        doubleSpinBox_vitesse->setValue(1);
        pushButton_tirer = new QPushButton(groupBox);
        pushButton_tirer->setObjectName(QString::fromUtf8("pushButton_tirer"));
        pushButton_tirer->setGeometry(QRect(10, 150, 151, 31));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 20, 151, 81));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 30, 46, 15));
        doubleSpinBox_theta = new QDoubleSpinBox(groupBox_2);
        doubleSpinBox_theta->setObjectName(QString::fromUtf8("doubleSpinBox_theta"));
        doubleSpinBox_theta->setGeometry(QRect(70, 20, 61, 25));
        doubleSpinBox_theta->setDecimals(0);
        doubleSpinBox_theta->setMinimum(-180);
        doubleSpinBox_theta->setMaximum(180);
        doubleSpinBox_theta->setSingleStep(10);
        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 60, 41, 16));
        doubleSpinBox_phi = new QDoubleSpinBox(groupBox_2);
        doubleSpinBox_phi->setObjectName(QString::fromUtf8("doubleSpinBox_phi"));
        doubleSpinBox_phi->setGeometry(QRect(70, 50, 61, 25));
        doubleSpinBox_phi->setDecimals(0);
        doubleSpinBox_phi->setMinimum(-90);
        doubleSpinBox_phi->setMaximum(90);
        doubleSpinBox_phi->setSingleStep(10);
        pushButton_simuler = new QPushButton(centralwidget);
        pushButton_simuler->setObjectName(QString::fromUtf8("pushButton_simuler"));
        pushButton_simuler->setGeometry(QRect(20, 210, 151, 32));
        MainWindow->setCentralWidget(centralwidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "P\303\251tanque Simulator", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "Joueur", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "Vitesse", 0, QApplication::UnicodeUTF8));
        pushButton_tirer->setText(QApplication::translate("MainWindow", "Tirer et simuler", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Direction", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "Theta", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "Phi", 0, QApplication::UnicodeUTF8));
        pushButton_simuler->setText(QApplication::translate("MainWindow", "Simuler", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINFORM_H
